import { useState } from 'react';
import FutureCity from '@/components/FutureCity';
import ControlPanel from '@/components/ControlPanel';
import StatsDisplay from '@/components/StatsDisplay';
import CityTitle from '@/components/CityTitle';

export default function Home() {
  const [isPaused, setIsPaused] = useState(false);
  const [speedMultiplier, setSpeedMultiplier] = useState(1);
  const [fps, setFps] = useState(60);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-background">
      <FutureCity
        isPaused={isPaused}
        speedMultiplier={speedMultiplier}
        onFpsUpdate={setFps}
      />

      <div className="absolute top-4 left-4 z-10">
        <CityTitle />
      </div>

      <div className="absolute top-4 right-4 z-10">
        <StatsDisplay
          fps={fps}
          drones={12}
          buildings={10}
          energySpheres={12}
        />
      </div>

      <div className="absolute bottom-4 right-4 z-10">
        <ControlPanel
          isPaused={isPaused}
          speedMultiplier={speedMultiplier}
          onPauseToggle={() => setIsPaused(!isPaused)}
          onSpeedChange={setSpeedMultiplier}
        />
      </div>
    </div>
  );
}
