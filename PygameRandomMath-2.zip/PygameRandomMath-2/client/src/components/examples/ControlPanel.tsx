import { useState } from 'react';
import ControlPanel from '../ControlPanel';

export default function ControlPanelExample() {
  const [isPaused, setIsPaused] = useState(false);
  const [speed, setSpeed] = useState(1);

  return (
    <div className="flex items-center justify-center min-h-[300px] bg-background p-8">
      <ControlPanel
        isPaused={isPaused}
        speedMultiplier={speed}
        onPauseToggle={() => {
          setIsPaused(!isPaused);
          console.log('Pause toggled:', !isPaused);
        }}
        onSpeedChange={(newSpeed) => {
          setSpeed(newSpeed);
          console.log('Speed changed:', newSpeed);
        }}
      />
    </div>
  );
}
