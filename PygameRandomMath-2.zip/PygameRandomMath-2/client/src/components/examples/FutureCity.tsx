import FutureCity from '../FutureCity';

export default function FutureCityExample() {
  return (
    <div className="w-full h-screen">
      <FutureCity />
    </div>
  );
}
