import CityTitle from '../CityTitle';

export default function CityTitleExample() {
  return (
    <div className="flex items-center justify-center min-h-[300px] bg-background p-8">
      <CityTitle />
    </div>
  );
}
