import StatsDisplay from '../StatsDisplay';

export default function StatsDisplayExample() {
  return (
    <div className="flex items-center justify-center min-h-[300px] bg-background p-8">
      <StatsDisplay fps={60} drones={12} buildings={10} energySpheres={12} />
    </div>
  );
}
