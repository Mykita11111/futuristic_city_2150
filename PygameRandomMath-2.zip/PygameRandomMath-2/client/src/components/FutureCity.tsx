import { useEffect, useRef, useState } from 'react';

interface Drone {
  x: number;
  y: number;
  speed: number;
  dir: number;
}

interface Building {
  x: number;
  y: number;
  w: number;
  h: number;
}

interface EnergySphere {
  x: number;
  y: number;
  radius: number;
  pulse: number;
}

interface Bridge {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  segments: number;
}

interface FutureCityProps {
  isPaused?: boolean;
  speedMultiplier?: number;
  onFpsUpdate?: (fps: number) => void;
}

export default function FutureCity({ 
  isPaused = false, 
  speedMultiplier = 1,
  onFpsUpdate 
}: FutureCityProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 1200, height: 700 });
  const animationFrameRef = useRef<number>();
  const dronesRef = useRef<Drone[]>([]);
  const buildingsRef = useRef<Building[]>([]);
  const energySpheresRef = useRef<EnergySphere[]>([]);
  const bridgesRef = useRef<Bridge[]>([]);
  const fpsRef = useRef({ frames: 0, lastTime: performance.now() });

  useEffect(() => {
    const handleResize = () => {
      setDimensions({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const WIDTH = dimensions.width;
    const HEIGHT = dimensions.height;
    const RIVER_Y = HEIGHT * 0.64;

    const random = (min: number, max: number) => Math.random() * (max - min) + min;

    const initializeDrones = () => {
      dronesRef.current = Array.from({ length: 12 }, () => ({
        x: random(0, WIDTH),
        y: random(HEIGHT * 0.14, HEIGHT * 0.43),
        speed: random(1, 3),
        dir: Math.random() > 0.5 ? 1 : -1,
      }));
    };

    const initializeBuildings = () => {
      buildingsRef.current = Array.from({ length: 10 }, () => ({
        x: random(WIDTH * 0.04, WIDTH * 0.9),
        y: random(HEIGHT * 0.29, RIVER_Y - 50),
        w: random(60, 120),
        h: random(150, 300),
      }));
    };

    const initializeEnergySpheres = () => {
      energySpheresRef.current = Array.from({ length: 12 }, () => ({
        x: random(WIDTH * 0.08, WIDTH * 0.92),
        y: random(HEIGHT * 0.14, HEIGHT * 0.57),
        radius: random(5, 15),
        pulse: random(0, 360),
      }));
    };

    const initializeBridges = () => {
      bridgesRef.current = [
        { x1: WIDTH * 0.08, y1: RIVER_Y, x2: WIDTH * 0.33, y2: RIVER_Y, segments: 10 },
        { x1: WIDTH * 0.5, y1: RIVER_Y, x2: WIDTH * 0.75, y2: RIVER_Y, segments: 10 },
      ];
    };

    initializeDrones();
    initializeBuildings();
    initializeEnergySpheres();
    initializeBridges();

    const drawDrone = (drone: Drone) => {
      ctx.shadowBlur = 15;
      ctx.shadowColor = 'rgba(255, 255, 50, 0.8)';
      ctx.fillStyle = '#FFFF32';
      ctx.beginPath();
      ctx.arc(drone.x, drone.y, 6, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.shadowBlur = 10;
      ctx.fillStyle = '#FFFFFF';
      ctx.beginPath();
      ctx.arc(drone.x, drone.y, 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    };

    const drawBuilding = (building: Building) => {
      ctx.fillStyle = '#64B4FA';
      ctx.fillRect(building.x, building.y, building.w, building.h);

      ctx.strokeStyle = '#00FFFF';
      ctx.lineWidth = 3;
      ctx.shadowBlur = 8;
      ctx.shadowColor = '#00FFFF';
      ctx.beginPath();
      ctx.moveTo(building.x, building.y);
      ctx.lineTo(building.x, building.y + building.h);
      ctx.stroke();
      ctx.beginPath();
      ctx.moveTo(building.x + building.w, building.y);
      ctx.lineTo(building.x + building.w, building.y + building.h);
      ctx.stroke();
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#FFFFCC';
      for (let i = 5; i < building.h; i += 15) {
        ctx.fillRect(building.x + 5, building.y + i, building.w - 10, 7);
      }
    };

    const drawEnergySphere = (sphere: EnergySphere) => {
      const r = sphere.radius + 3 * Math.sin((sphere.pulse * Math.PI) / 180);
      ctx.fillStyle = '#FF00FF';
      ctx.shadowBlur = 20;
      ctx.shadowColor = '#FF00FF';
      ctx.beginPath();
      ctx.arc(sphere.x, sphere.y, r, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
    };

    const drawBridge = (bridge: Bridge) => {
      ctx.strokeStyle = '#C832FA';
      ctx.lineWidth = 4;
      ctx.shadowBlur = 6;
      ctx.shadowColor = '#C832FA';
      for (let i = 0; i < bridge.segments; i++) {
        const t1 = i / bridge.segments;
        const t2 = (i + 1) / bridge.segments;
        const x1 = bridge.x1 + (bridge.x2 - bridge.x1) * t1;
        const y1 = bridge.y1 + (bridge.y2 - bridge.y1) * t1;
        const x2 = bridge.x1 + (bridge.x2 - bridge.x1) * t2;
        const y2 = bridge.y1 + (bridge.y2 - bridge.y1) * t2;
        ctx.beginPath();
        ctx.moveTo(x1, y1);
        ctx.lineTo(x2, y2);
        ctx.stroke();
      }
      ctx.shadowBlur = 0;
    };

    const updateDrones = () => {
      dronesRef.current.forEach((drone) => {
        drone.x += drone.speed * drone.dir * speedMultiplier;
        if (drone.x < 0 || drone.x > WIDTH) {
          drone.dir *= -1;
        }
      });
    };

    const updateEnergySpheres = () => {
      energySpheresRef.current.forEach((sphere) => {
        sphere.pulse += 5 * speedMultiplier;
        if (sphere.pulse > 360) sphere.pulse = 0;
      });
    };

    const animate = () => {
      if (!isPaused) {
        ctx.fillStyle = '#0A0A28';
        ctx.fillRect(0, 0, WIDTH, HEIGHT);

        ctx.fillStyle = '#0F3282';
        ctx.fillRect(0, RIVER_Y, WIDTH, HEIGHT - RIVER_Y);

        bridgesRef.current.forEach(drawBridge);
        buildingsRef.current.forEach(drawBuilding);
        energySpheresRef.current.forEach(drawEnergySphere);
        dronesRef.current.forEach(drawDrone);

        updateDrones();
        updateEnergySpheres();

        fpsRef.current.frames++;
        const now = performance.now();
        if (now - fpsRef.current.lastTime >= 1000) {
          if (onFpsUpdate) {
            onFpsUpdate(fpsRef.current.frames);
          }
          fpsRef.current.frames = 0;
          fpsRef.current.lastTime = now;
        }
      }

      animationFrameRef.current = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [dimensions, isPaused, speedMultiplier, onFpsUpdate]);

  return (
    <canvas
      ref={canvasRef}
      width={dimensions.width}
      height={dimensions.height}
      className="block"
      data-testid="canvas-city"
    />
  );
}
