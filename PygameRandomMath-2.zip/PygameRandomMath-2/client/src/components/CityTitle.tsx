import { Card } from '@/components/ui/card';

export default function CityTitle() {
  return (
    <Card className="backdrop-blur-md bg-background/20 border-chart-1/30 p-4">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold tracking-wider text-chart-1" data-testid="text-title">
          CITY 2150
        </h1>
        <p className="text-xs text-muted-foreground font-light tracking-wide">
          Cyberpunk Metropolis Simulation
        </p>
      </div>
    </Card>
  );
}
