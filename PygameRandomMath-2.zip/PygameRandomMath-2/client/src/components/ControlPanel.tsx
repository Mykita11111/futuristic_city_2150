import { Pause, Play, Minus, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface ControlPanelProps {
  isPaused: boolean;
  speedMultiplier: number;
  onPauseToggle: () => void;
  onSpeedChange: (speed: number) => void;
}

export default function ControlPanel({
  isPaused,
  speedMultiplier,
  onPauseToggle,
  onSpeedChange,
}: ControlPanelProps) {
  const handleSpeedDecrease = () => {
    const newSpeed = Math.max(0.25, speedMultiplier - 0.25);
    onSpeedChange(newSpeed);
  };

  const handleSpeedIncrease = () => {
    const newSpeed = Math.min(2, speedMultiplier + 0.25);
    onSpeedChange(newSpeed);
  };

  return (
    <Card className="backdrop-blur-md bg-background/20 border-chart-1/30 p-4">
      <div className="flex flex-col gap-3">
        <div className="flex items-center gap-2">
          <Button
            size="icon"
            variant="outline"
            onClick={onPauseToggle}
            className="hover-elevate active-elevate-2 border-chart-1/30"
            data-testid="button-pause-toggle"
          >
            {isPaused ? (
              <Play className="h-4 w-4" data-testid="icon-play" />
            ) : (
              <Pause className="h-4 w-4" data-testid="icon-pause" />
            )}
          </Button>
          <span className="text-sm font-mono text-foreground" data-testid="text-pause-status">
            {isPaused ? 'Paused' : 'Running'}
          </span>
        </div>

        <div className="flex flex-col gap-2">
          <span className="text-xs font-mono text-muted-foreground">Speed</span>
          <div className="flex items-center gap-2">
            <Button
              size="icon"
              variant="outline"
              onClick={handleSpeedDecrease}
              disabled={speedMultiplier <= 0.25}
              className="h-8 w-8 hover-elevate active-elevate-2 border-chart-1/30"
              data-testid="button-speed-decrease"
            >
              <Minus className="h-3 w-3" />
            </Button>
            <span className="text-sm font-mono w-12 text-center text-foreground" data-testid="text-speed">
              {speedMultiplier.toFixed(2)}x
            </span>
            <Button
              size="icon"
              variant="outline"
              onClick={handleSpeedIncrease}
              disabled={speedMultiplier >= 2}
              className="h-8 w-8 hover-elevate active-elevate-2 border-chart-1/30"
              data-testid="button-speed-increase"
            >
              <Plus className="h-3 w-3" />
            </Button>
          </div>
        </div>
      </div>
    </Card>
  );
}
