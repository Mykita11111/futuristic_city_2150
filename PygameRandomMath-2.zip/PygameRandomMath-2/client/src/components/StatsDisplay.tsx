import { Card } from '@/components/ui/card';

interface StatsDisplayProps {
  fps: number;
  drones?: number;
  buildings?: number;
  energySpheres?: number;
}

export default function StatsDisplay({
  fps,
  drones = 12,
  buildings = 10,
  energySpheres = 12,
}: StatsDisplayProps) {
  return (
    <Card className="backdrop-blur-md bg-background/20 border-chart-1/30 p-4">
      <div className="flex flex-col gap-2">
        <h3 className="text-xs font-bold tracking-wider text-chart-1 uppercase">
          System Stats
        </h3>
        <div className="flex flex-col gap-1 font-mono text-xs">
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">FPS:</span>
            <span className="text-foreground font-medium" data-testid="text-fps">{fps}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">Drones:</span>
            <span className="text-foreground" data-testid="text-drones">{drones}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">Buildings:</span>
            <span className="text-foreground" data-testid="text-buildings">{buildings}</span>
          </div>
          <div className="flex justify-between gap-4">
            <span className="text-muted-foreground">Energy:</span>
            <span className="text-foreground" data-testid="text-energy">{energySpheres}</span>
          </div>
        </div>
      </div>
    </Card>
  );
}
