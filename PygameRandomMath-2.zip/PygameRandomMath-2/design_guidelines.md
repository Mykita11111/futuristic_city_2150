# Design Guidelines: Futuristic City 2150 Visualization

## Design Approach
**Reference-Based Approach:** Drawing inspiration from cyberpunk aesthetics (Blade Runner, Cyberpunk 2077), modern data visualizations, and immersive web experiences like Bruno Simon's portfolio. This is a visual experience project where atmosphere and motion create engagement.

## Core Design Principles
- **Atmospheric Immersion:** Full-viewport canvas creating a living, breathing futuristic world
- **Neon Noir:** Dark backgrounds with vibrant cyan, magenta, and yellow accents creating depth
- **Kinetic Energy:** Constant subtle motion conveying a dynamic, alive cityscape
- **Technological Sophistication:** Clean geometric forms with glowing edges suggesting advanced architecture

## Color Palette

**Dark Mode (Primary):**
- Background Sky: 240 75% 8% (deep navy-black)
- River Water: 220 80% 15% (dark electric blue)
- Building Base: 200 60% 45% (steel blue-gray)
- Neon Cyan Glow: 180 100% 50%
- Neon Magenta Energy: 300 100% 50%
- Drone Yellow: 55 100% 60%
- Bridge Purple: 270 80% 55%
- Window Light: 50 100% 80% (warm amber)

## Typography
**Font Families:**
- Primary: 'Orbitron' (Google Fonts) - futuristic display font for UI overlays
- Monospace: 'Roboto Mono' - for data/stats if added

**Hierarchy:**
- Title (if added): text-4xl font-bold tracking-wider
- Stats/Info: text-sm font-light tracking-wide

## Layout System

**Spacing Primitives:** Use Tailwind units of 2, 4, 8, and 16 for consistent rhythm

**Canvas Structure:**
- Full viewport (100vw × 100vh) HTML5 Canvas
- No traditional margins/padding - immersive edge-to-edge
- Optional overlay UI in corners using absolute positioning
- Bottom-right: Controls (pause, speed adjustment)
- Top-left: Title/branding with backdrop blur

## Component Library

### A. Canvas Elements

**Buildings:**
- Rectangular forms with 60-120px width, 150-300px height
- 3px cyan neon edge glow on vertical sides
- Horizontal window strips (7px height) with warm amber glow
- Varied heights creating dynamic skyline silhouette

**Drones:**
- 12px circular bodies with yellow fill
- 4px white core light
- Smooth diagonal movement patterns
- Speed variation (1-3 units/frame)

**Energy Spheres:**
- Pulsating circles (10-30px radius)
- Magenta fills with sinusoidal radius animation
- Scattered throughout mid-air
- 0.5s-2s pulse cycles varying per sphere

**Bridges:**
- 4px stroke width purple gradient lines
- Segmented for visual interest (10+ segments)
- Spanning river horizontally

**River:**
- Bottom 35% of viewport
- Subtle horizontal flow animation optional
- Darker blue establishing ground plane

### B. UI Overlay Components (Optional Enhancement)

**Control Panel:**
- Glassmorphic card (backdrop-blur-md bg-black/20)
- Rounded corners (rounded-lg)
- Border with cyan glow (border border-cyan-500/30)
- Icon buttons for pause/play, speed controls
- Positioned bottom-right with p-4 spacing

**Stats Display:**
- FPS counter in monospace font
- Object counts (drones, buildings, spheres)
- Minimal, non-intrusive top-right placement

## Animations & Interactions

**Animation Strategy:**
- Continuous 60fps requestAnimationFrame loop
- No user-triggered animations - autonomous motion
- Smooth easing for drone direction changes
- Pulsing glow effects using Math.sin() for organic feel

**Interactive Elements:**
- Pause/Resume toggle
- Speed multiplier slider (0.5x to 2x)
- Hover states on controls with cyan glow intensification

## Technical Specifications

**Canvas Rendering:**
- 2D context with antialiasing enabled
- Layer order: Sky → River → Bridges → Buildings → Energy Spheres → Drones
- Shadow/glow effects using context.shadowBlur and shadowColor
- Gradient fills for depth on buildings

**Responsive Behavior:**
- Canvas resizes to window dimensions
- Object positions scale proportionally
- Maintain 16:9 aspect ratio logic for consistent composition

**Performance:**
- Target 60fps
- Efficient redraw: clear canvas then render all layers
- Object pooling for drones and spheres

## Accessibility
- Provide "Reduce Motion" toggle respecting prefers-reduced-motion
- When reduced motion active: freeze animations, show static cityscape
- Keyboard controls: Space for pause, Arrow keys for speed adjustment
- Screen reader announcement for animation state changes

## Visual Enhancements
- Add subtle scanline overlay (repeating-linear-gradient) for retro-futuristic feel
- Implement glow/bloom post-processing using compositing modes
- Occasional lightning flashes in sky for drama
- Parallax effect on buildings if mouse tracking added

This visualization prioritizes atmospheric immersion through constant motion, vibrant neon accents against dark backgrounds, and a cohesive cyberpunk aesthetic that transports users to a living futuristic metropolis.